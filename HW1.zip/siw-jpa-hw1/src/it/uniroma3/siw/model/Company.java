package it.uniroma3.siw.model;

import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Company {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id; //ragione sociale
	
	private Long phoneNumber;	
	
	@ManyToOne (cascade = {CascadeType.PERSIST})
	/*e' molto probabile che alla creazione di una istanza di company venga creata anche creata una istanza 
	 *di address dunque e' utile che l'operazone persist venga propagata 
	 *cio' non e' altrattanto valido per la remove in quanto un address potrebbe essere associato a piu' company
	 */
	private Address address;

	public Company(Long id, Long phoneNumber, Address address) {
		this.id = id;
		this.phoneNumber = phoneNumber;
		this.address = address;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Company other = (Company) obj;
		return Objects.equals(id, other.id);
	}
	
}
